﻿using System;

public interface Sound
{
    string produceSound();
}