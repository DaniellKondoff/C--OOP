﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Froggy
{
    class StartUp
    {
        static void Main()
        {
            List<int> inputNumbers = Console.ReadLine().Split(',').Select(int.Parse).ToList();
        

            Lake collection = new Lake(inputNumbers);
            string result = string.Empty;
            foreach (var item in collection)
            {
                result += item + ", ";
            }
            Console.WriteLine(result.Remove(result.Length-2));
        }
    }
}
